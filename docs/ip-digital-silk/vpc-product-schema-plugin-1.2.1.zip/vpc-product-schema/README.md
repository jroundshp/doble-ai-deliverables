# InterActive Play — Product Schema plugin, v1.2.1

Everything this plugin publishes is **already written on the product pages**. It adds no new
claims about any product. It labels the specifications so search engines and AI assistants can
read them as specifications.

## What changed in 1.2.1 (21 September 2026)

Five specifications now match the pages and the current data sheets: Cannon 35 GPM,
Power Plunge 150 GPM, Rain Maker 24 GPM and 111 in., Triple Buzz 5 GPM, Thump Pump
9" x 13" x 29". The "How many guests" answer on Waterfall Model 200, 300 and 400 carries the
tidied wording that is going onto those three pages. Nothing else changed.

## What it covers

**All 24 product pages** get a `Product` record built from that page's own spec table.

- **Aquatic play structures (9):** TriWave Model 100, 200, 300 · Misty Island 100, 200 ·
  Waterfall Model 100, 200, 300, 400. Nine specifications each: venue, unit size, footprint,
  waterslides, deck height, battle zones, feature count, capacity, application.
- **Water play features (15):** Beanstalk Blaster, Cannon, Fanatic, Jet Stream, Oh Chute,
  Pour Over, Power Plunge, Puddle Juggle, Rain Maker, Rusher, Three Tree, Thump Pump,
  Triple Buzz, Wee Womper, WhiteWash. Activation type, dimensions, flow requirement,
  components and applications (plus water volume and spray pattern on the Power Plunge).

**The 9 aquatic play structure pages also get an `FAQPage` record** for the three questions in
their "Got Questions? We've Got Answers!" panel, copied word for word from the page.

The 15 water play feature pages get no FAQ record: their panel still carries the three general
multi-level play structure questions, and the same questions repeated on many pages earn nothing.

## Keeping it in step with the pages

The plugin holds a copy of each page's figures and FAQ text. **If a spec or an FAQ answer is
edited on a page, edit the same line in `vpc-product-schema.php`**, or delete that page's `faq`
entry. Google requires the marked-up questions to match what a visitor can see.

## Installing / updating

Plugins → Add New → Upload Plugin → choose the zip → Install Now. If v1.1 or v1.2 is already installed,
WordPress offers **Replace current with uploaded**; choose it. Then clear the site's page cache,
if it has one, so pages pick up the new version. Nothing else to configure.
Deactivating removes everything it adds.

## Checking it

Paste any product page address into https://validator.schema.org/. A structure page shows a
Product and an FAQPage; a water play feature page shows a Product.

## Deliberate decisions

- **No price and no offer.** These are quoted capital purchases, and an offer without a price is
  flagged as an error by Google. Do not add a price to satisfy a validator warning.
- **Only what the page shows.** Descriptions are the page's own first paragraph (structures use a
  one-line summary of their own spec table). No related-product links, audience or availability
  claims, because the pages do not publish them.
- **No second company record.** Yoast already publishes the InterActive Play Organization at
  `https://interactivewaterparks.com/#organization`; the plugin points to it by `@id`.
- **No image on Waterfall Model 400.** None of the images on that page is labelled as the Model 400
  (no alt text, file names that do not name the model), so none is marked up. Add one here once
  VPC confirms which image shows it.
- **Unit codes** (UN/CEFACT): `FTK` square foot, `INH` inch, `C62` count, `G2` US gallon per
  minute, `GLL` US gallon.

Prepared by Doble AI · 14 September 2026, updated 21 September 2026 · john@dobleai.com
