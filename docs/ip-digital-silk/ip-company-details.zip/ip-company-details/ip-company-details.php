<?php
/**
 * Plugin Name: InterActive Play - Company Details
 * Description: Adds the phone number, street address and VPC as parent company to the organization record Yoast SEO already publishes on every page. Adds no second record.
 * Version: 1.0
 *
 * Yoast SEO (free) has no field for an address or a parent company, so this fills them in
 * through Yoast's own filter. The figures are the ones on the Get in Touch page.
 * Deactivating removes everything it adds.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'wpseo_schema_organization', function ( $data ) {
    $data['telephone'] = '+1-585-735-9668';
    $data['address'] = array(
        '@type'           => 'PostalAddress',
        'streetAddress'   => '222 S Niagara Street',
        'addressLocality' => 'Lockport',
        'addressRegion'   => 'NY',
        'postalCode'      => '14094',
        'addressCountry'  => 'US',
    );
    $data['parentOrganization'] = array(
        '@type' => 'Organization',
        'name'  => 'Virtual Polymer Compounds',
        'url'   => 'https://www.vpcfiberglass.com/',
    );
    return $data;
} );
