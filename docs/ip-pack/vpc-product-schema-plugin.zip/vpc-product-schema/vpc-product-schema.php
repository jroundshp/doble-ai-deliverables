<?php
/**
 * Plugin Name: InterActive Play - Product Schema
 * Description: Emits Product JSON-LD on product pages. Additive: leaves Yoast's existing blocks alone.
 * Version: 1.1
 *
 * WHAT THIS DOES
 *   Publishes the specifications already written on each product page in a form search
 *   engines and AI assistants can parse. It adds no new claims to the site.
 *
 * HOW TO USE
 *   1. Drop this file in wp-content/plugins/ and activate, or paste the two functions
 *      into the child theme's functions.php.
 *   2. Fill in $VPC_PRODUCTS below, one entry per product page, using the values that
 *      are already on that page. Start with the nine aquatic play structures.
 *   3. Confirm with Google's Rich Results Test before and after.
 *
 * DELIBERATELY NO PRICE. These are quoted capital purchases. See README.md.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * One entry per product page, keyed by the page path.
 * 'specs' is an ordered list of [label, value, unitCode|null, description|null].
 * unitCode: FTK = square feet, INH = inches, C62 = a plain count.
 */
$GLOBALS['VPC_PRODUCTS'] = array(

  '/products/aquatic-play-structures/triwave-100/' => array(
    'name'     => 'TriWave Model 100',
    'sku'      => 'TRIWAVE-100',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Multi-level aquatic play structure with 20 interactive water features, two closed flume tube slides, a giant tippy bucket and a single water battle zone. Occupies a 4,300 sq ft minimum footprint and serves up to 172 water players in a 6 to 8 inch shallow depth pool.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2025/05/Triwave-100-Render-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/05/Triwave-100-Render-2.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/05/Triwave-100-Render-5.png',
    ),
    'crumb'    => array( 'Aquatic Play Structures', '/products/aquatic-play-structures/' ),
    'related'  => array(
      array( 'TriWave Model 200', '/products/aquatic-play-structures/triwave-200/' ),
      array( 'TriWave Model 300', '/products/aquatic-play-structures/triwave-300/' ),
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', "60' x 45' x 16' 7\"", null, null ),
      array( 'Minimum Required Footprint', '4300', 'FTK', '4300 sq ft / 399.4 sq m' ),
      array( 'Waterslides', '2', 'C62', '2 closed flume tube slides (8 ft and 9 ft high)' ),
      array( 'Top Deck Height', '108', 'INH', '108 in / 2.74 m' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '20', 'C62', null ),
      array( 'User Capacity (structure + pool)', '172', 'C62', 'Up to 172 water players' ),
      array( 'Application', 'Shallow depth pool 6-8 inches deep', null, null ),
    ),
  ),

  // Copy the block above for each remaining product page. The 23 others are listed in README.md.

);

function vpc_product_schema_graph( $path, $p ) {
	$base = 'https://interactivewaterparks.com';
	$url  = $base . $path;

	// Yoast already publishes the Organization node at $base . '/#organization'.
	// We reference it by @id rather than redefining it: two nodes sharing one @id
	// with different values is a conflict, and Yoast's own settings are the right
	// place for the address, phone and parent company.

	$props = array();
	foreach ( $p['specs'] as $s ) {
		list( $label, $value, $unit, $desc ) = $s;
		$pv = array( '@type' => 'PropertyValue', 'name' => $label, 'value' => $value );
		if ( $unit ) $pv['unitCode']    = $unit;
		if ( $desc ) $pv['description'] = $desc;
		$props[] = $pv;
	}

	$related = array();
	foreach ( ( isset( $p['related'] ) ? $p['related'] : array() ) as $r ) {
		$related[] = array( '@type' => 'Product', 'name' => $r[0], 'url' => $base . $r[1] );
	}

	$product = array(
		'@type'       => 'Product',
		'@id'         => $url . '#product',
		'name'        => $p['name'],
		'sku'         => $p['sku'],
		'mpn'         => $p['sku'],
		'category'    => $p['category'],
		'url'         => $url,
		'description' => $p['desc'],
		'image'       => $p['images'],
		'brand'       => array( '@type' => 'Brand', 'name' => 'InterActive Play' ),
		'manufacturer'=> array( '@id' => $base . '/#organization' ),
		'audience'    => array(
			'@type' => 'BusinessAudience',
			'name'  => 'Waterparks, resorts, RV campgrounds and municipal recreation facilities',
		),
		'additionalProperty' => $props,
		'offers' => array(
			'@type'            => 'Offer',
			'availability'     => 'https://schema.org/InStock',
			'businessFunction' => 'http://purl.org/goodrelations/v1#Sell',
			'seller'           => array( '@id' => $base . '/#organization' ),
			'url'              => $base . '/contact/',
			'areaServed'       => array( '@type' => 'Country', 'name' => 'United States' ),
		),
	);
	if ( $related ) $product['isRelatedTo'] = $related;

	return array(
		'@context' => 'https://schema.org',
		'@graph'   => array( $product ),
	);
}

function vpc_emit_product_schema() {
	if ( is_admin() ) return;
	$path = trailingslashit( strtok( $_SERVER['REQUEST_URI'], '?' ) );
	if ( ! isset( $GLOBALS['VPC_PRODUCTS'][ $path ] ) ) return;

	$graph = vpc_product_schema_graph( $path, $GLOBALS['VPC_PRODUCTS'][ $path ] );
	echo "\n<script type=\"application/ld+json\">"
	   . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	   . "</script>\n";
}
add_action( 'wp_head', 'vpc_emit_product_schema', 20 );
