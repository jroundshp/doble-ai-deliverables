<?php
/**
 * Plugin Name: InterActive Play - Product Schema
 * Description: Emits Product JSON-LD on the 24 product pages, plus FAQPage on the 9 aquatic play structures. Additive: leaves Yoast's existing blocks alone.
 * Version: 1.2
 *
 * WHAT THIS DOES
 *   Publishes the specifications already written on each product page in a form search
 *   engines and AI assistants can parse. It adds no new claims to the site.
 *
 *   On the nine aquatic play structure pages it also marks up the three questions in the
 *   "Got Questions? We've Got Answers!" panel. The text in 'faq' must match the page word for
 *   word: if the questions on a page are edited, edit them here too, or delete that page's
 *   'faq' entry.
 *
 * UPDATING FROM 1.1
 *   Plugins > Add New > Upload Plugin, choose this zip, then "Replace current with uploaded".
 *
 * DELIBERATELY NO PRICE AND NO OFFER. These are quoted capital purchases, and an offer with
 * no price is flagged as an error by Google. Everything here is visible on the page it describes.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * One entry per product page, keyed by the page path.
 * 'specs' is an ordered list of [label, value, unitCode|null, description|null].
 * unitCode: FTK = square feet, INH = inches, C62 = a plain count,
 *           G2 = US gallons per minute, GLL = US gallons.
 */
$GLOBALS['VPC_PRODUCTS'] = array(

  // Aquatic play structures (9)
  '/products/aquatic-play-structures/triwave-100/' => array(
    'name'     => 'TriWave Model 100',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'TriWave Model 100: 20 interactive water features, 2 waterslides and a single water battle zone. Requires a 4,300 sq ft minimum footprint and serves up to 172 water players. Application: shallow depth pool 6-8 inches deep.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2025/05/Triwave-100-Render-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/05/Triwave-100-Render-2.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/05/Triwave-100-Render-5.png',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '60’ x 45’ x 16’ 7”', null, null ),
      array( 'Minimum Required Footprint', '4300', 'FTK', '4300 SQ. FT. / 399.4 SQ. M.' ),
      array( 'Waterslides', '2', 'C62', '2 slides – closed flume tube slides (8 FT. and 9 FT. high)' ),
      array( 'Top Deck Height', '108', 'INH', '108 IN. / 2.74 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '20', 'C62', null ),
      array( 'User Capacity (structure + pool)', '172', 'C62', 'Up to 172 water players' ),
      array( 'Application', 'Shallow depth pool 6-8 inches deep', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the TriWave Model 100 need?',
             'The TriWave Model 100 requires a minimum footprint of 4,300 sq ft / 399.4 sq m. The unit itself measures 60’ x 45’ x 16’ 7” (L/W/H), with a top deck height of 108 in / 2.74 m.' ),
      array( 'How many guests can the TriWave Model 100 serve?',
             'Up to 172 water players. The structure carries 20 interactive water features and 2 slides – closed flume tube slides (8 ft and 9 ft high).' ),
      array( 'What kind of pool does the TriWave Model 100 install over?',
             'Shallow depth pool 6-8 inches deep. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/triwave-200/' => array(
    'name'     => 'TriWave Model 200',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'TriWave Model 200: 10 interactive water features, 4 waterslides and a single water battle zone. Requires a 4,300 sq ft minimum footprint and serves up to 172 water players. Application: shallow depth pool 6-8 inches deep.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2025/04/Triwave-2-Render-4.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/04/Triwave-2-Render-3.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/04/Triwave-2-Render-5.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/08/TriWave-200-wKiddie-Zone-1.png',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '63’ 3” x 47’ 4” x 18’ 8”', null, null ),
      array( 'Minimum Required Footprint', '4300', 'FTK', '4300 SQ. FT. / 399.4 SQ. M.' ),
      array( 'Waterslides', '4', 'C62', '4 slides – 3 large, closed flume body slides and 1 open flume slide' ),
      array( 'Top Deck Height', '108', 'INH', '108 IN. / 2.74 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '10', 'C62', null ),
      array( 'User Capacity (structure + pool)', '172', 'C62', 'Up to 172 water players' ),
      array( 'Application', 'Shallow depth pool 6-8 inches deep', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the TriWave Model 200 need?',
             'The TriWave Model 200 requires a minimum footprint of 4,300 sq ft / 399.4 sq m. The unit itself measures 63’ 3” x 47’ 4” x 18’ 8” (L/W/H), with a top deck height of 108 in / 2.74 m.' ),
      array( 'How many guests can the TriWave Model 200 serve?',
             'Up to 172 water players. The structure carries 10 interactive water features and 4 slides – 3 large, closed flume body slides and 1 open flume slide.' ),
      array( 'What kind of pool does the TriWave Model 200 install over?',
             'Shallow depth pool 6-8 inches deep. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/triwave-300/' => array(
    'name'     => 'TriWave Model 300',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'TriWave Model 300: 26 interactive water features, 4 waterslides and a single water battle zone. Requires a 6,300 sq ft minimum footprint and serves up to 420 water players. Application: shallow depth pool 6-8 inches deep.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2025/08/TriWave-Model-300.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2025/08/Triwave-300-Render-5.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/08/Triwave-300-Render-4.png',
      'https://interactivewaterparks.com/wp-content/uploads/2025/08/Triwave-300-Render-3.png',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '62’ 8” x 54’ x 18’ 8”', null, null ),
      array( 'Minimum Required Footprint', '6300', 'FTK', '6300 SQ. FT. / 585.3 SQ. M.' ),
      array( 'Waterslides', '4', 'C62', '4 slides – 3 large, closed flume body slides and 1 open flume slide' ),
      array( 'Top Deck Height', '108', 'INH', '108 IN. / 2.74 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '26', 'C62', null ),
      array( 'User Capacity (structure + pool)', '420', 'C62', 'Up to 420 water players' ),
      array( 'Application', 'Shallow depth pool 6-8 inches deep', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the TriWave Model 300 need?',
             'The TriWave Model 300 requires a minimum footprint of 6,300 sq ft / 585.3 sq m. The unit itself measures 62’ 8” x 54’ x 18’ 8” (L/W/H), with a top deck height of 108 in / 2.74 m.' ),
      array( 'How many guests can the TriWave Model 300 serve?',
             'Up to 420 water players. The structure carries 26 interactive water features and 4 slides – 3 large, closed flume body slides and 1 open flume slide.' ),
      array( 'What kind of pool does the TriWave Model 300 install over?',
             'Shallow depth pool 6-8 inches deep. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/misty-island-100/' => array(
    'name'     => 'Misty Island 100',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Misty Island 100: 37 interactive water features, 3 waterslides and a single water battle zone. Requires a 5,300 sq ft minimum footprint and serves up to 212 water players. Application: shallow depth pool 6-8 inches deep.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/misty-island-model-100-01-2.jpg',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '47’8″ x 26’2″ x 28’6″', null, null ),
      array( 'Minimum Required Footprint', '5300', 'FTK', '5300 SQ. FT. / 492.3 SQ. M.' ),
      array( 'Waterslides', '3', 'C62', '3 slides – Large open flume body slide and toddler racers' ),
      array( 'Top Deck Height', '180', 'INH', '180 IN. / 4.5 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '37', 'C62', null ),
      array( 'User Capacity (structure + pool)', '212', 'C62', 'Up to 212 water players' ),
      array( 'Application', 'Shallow depth pool 6-8 inches deep', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the Misty Island 100 need?',
             'The Misty Island 100 requires a minimum footprint of 5,300 sq ft / 492.3 sq m. The unit itself measures 47’8″ x 26’2″ x 28’6″ (L/W/H), with a top deck height of 180 in / 4.5 m.' ),
      array( 'How many guests can the Misty Island 100 serve?',
             'Up to 212 water players. The structure carries 37 interactive water features and 3 slides – Large open flume body slide and toddler racers.' ),
      array( 'What kind of pool does the Misty Island 100 install over?',
             'Shallow depth pool 6-8 inches deep. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/misty-island-200/' => array(
    'name'     => 'Misty Island 200',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Misty Island 200: 40 interactive water features, 4 waterslides and a single water battle zone. Requires a 6,000 sq ft minimum footprint and serves up to 240 water players. Application: shallow depth pool 6-8 inches deep.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/misty-island-model-200-01-1.jpg',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '51’10” x 20’9″ x 30’10″', null, null ),
      array( 'Minimum Required Footprint', '6000', 'FTK', '6000 SQ. FT. / 557.4 SQ. M.' ),
      array( 'Waterslides', '4', 'C62', '4 slides – 2 large open flume body slides and 2 toddler racers' ),
      array( 'Top Deck Height', '180', 'INH', '180 IN. / 4.5 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '40', 'C62', null ),
      array( 'User Capacity (structure + pool)', '240', 'C62', 'Up to 240 water players' ),
      array( 'Application', 'Shallow depth pool 6-8 inches deep', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the Misty Island 200 need?',
             'The Misty Island 200 requires a minimum footprint of 6,000 sq ft / 557.4 sq m. The unit itself measures 51’10” x 20’9″ x 30’10″ (L/W/H), with a top deck height of 180 in / 4.5 m.' ),
      array( 'How many guests can the Misty Island 200 serve?',
             'Up to 240 water players. The structure carries 40 interactive water features and 4 slides – 2 large open flume body slides and 2 toddler racers.' ),
      array( 'What kind of pool does the Misty Island 200 install over?',
             'Shallow depth pool 6-8 inches deep. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/waterfall-model-100/' => array(
    'name'     => 'Waterfall Model 100',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Waterfall Model 100: 13 interactive water features, 3 waterslides and a single water battle zone. Requires a 3,700 sq ft minimum footprint and serves up to 148 water players. Application: shallow depth pool 6-12 inches deep.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/waterfall-100-back-01.jpg',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Waterparks; Indoor Waterparks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '18’9” x 24’10” x 25’6”', null, null ),
      array( 'Minimum Required Footprint', '3700', 'FTK', '3700 SQ. FT. / 343.7 SQ. M.' ),
      array( 'Water Slides', '3', 'C62', '3 slides – 2 toddler racers and an open flume body slide' ),
      array( 'Top Deck Height', '84', 'INH', '84 IN. / 2.13 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '13', 'C62', null ),
      array( 'User Capacity (structure + pool)', '148', 'C62', 'Up to 148 water players' ),
      array( 'Application', 'Shallow depth pool 6-12 inches deep', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the Waterfall Model 100 need?',
             'The Waterfall Model 100 requires a minimum footprint of 3,700 sq ft / 343.7 sq m. The unit itself measures 18’9” x 24’10” x 25’6” (L/W/H), with a top deck height of 84 in / 2.13 m.' ),
      array( 'How many guests can the Waterfall Model 100 serve?',
             'Up to 148 water players. The structure carries 13 interactive water features and 3 slides – 2 toddler racers and an open flume body slide.' ),
      array( 'What kind of pool does the Waterfall Model 100 install over?',
             'Shallow depth pool 6-12 inches deep. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/waterfall-model-200/' => array(
    'name'     => 'Waterfall Model 200',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Waterfall Model 200: 10 interactive water features, 4 waterslides and a single water battle zone. Requires a 2,700 sq ft minimum footprint and serves up to 108 water players. Application: shallow depth pool or zero-depth pool.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/waterfall-model-200-01-2-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/play-structure-model-200-back-01.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/waterfall-model-200-02-1.jpg',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Water Parks; Indoor Water Parks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '16’ x 24’8” x 25’', null, null ),
      array( 'Minimum Required Footprint', '2700', 'FTK', '2700 SQ. FT. / 250.8 SQ. M.' ),
      array( 'Waterslides', '4', 'C62', '4 – Enclosed tube slides' ),
      array( 'Top Deck Height', '66', 'INH', '66 IN. / 1.6 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '10', 'C62', null ),
      array( 'User Capacity (structure + pool)', '108', 'C62', 'Up to 108 water players' ),
      array( 'Application', 'Shallow depth pool or zero-depth pool', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the Waterfall Model 200 need?',
             'The Waterfall Model 200 requires a minimum footprint of 2,700 sq ft / 250.8 sq m. The unit itself measures 16’ x 24’8” x 25’ (L/W/H), with a top deck height of 66 in / 1.6 m.' ),
      array( 'How many guests can the Waterfall Model 200 serve?',
             'Up to 108 water players. The structure carries 10 interactive water features and 4 – Enclosed tube slides.' ),
      array( 'What kind of pool does the Waterfall Model 200 install over?',
             'Shallow depth pool or zero-depth pool. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/waterfall-model-300/' => array(
    'name'     => 'Waterfall Model 300',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Waterfall Model 300: 12 interactive water features, 2 waterslides and a single water battle zone. Requires a 3,550 sq ft minimum footprint and serves up to 142 water players. Application: shallow depth pool.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/waterfall-model-300-01.jpg',
    ),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Water Parks; Indoor Water Parks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '24’8″ x 29’ x 24’10″', null, null ),
      array( 'Minimum Required Footprint', '3550', 'FTK', '3550 SQ. FT. / 329.8 SQ. M.' ),
      array( 'Waterslides', '2', 'C62', '2 – Open flume body slide and enclosed tube slide' ),
      array( 'Top Deck Height', '78', 'INH', '78 IN. / 1.9 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '12', 'C62', null ),
      array( 'User Capacity (structure + pool)', '142', 'C62', 'Up to 142 water players' ),
      array( 'Application', 'Shallow depth pool', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the Waterfall Model 300 need?',
             'The Waterfall Model 300 requires a minimum footprint of 3,550 sq ft / 329.8 sq m. The unit itself measures 24’8″ x 29’ x 24’10″ (L/W/H), with a top deck height of 78 in / 1.9 m.' ),
      array( 'How many guests can the Waterfall Model 300 serve?',
             'Up to 142 water players. The structure carries 12 interactive water features and 2 – Open flume body slide and enclosed tube slide.' ),
      array( 'What kind of pool does the Waterfall Model 300 install over?',
             'Shallow depth pool. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  '/products/aquatic-play-structures/multi-level-water-play-unit-waterfall-model-400/' => array(
    'name'     => 'Waterfall Model 400',
    'category' => 'Aquatic Play Structures > Multi-Level Water Play Units',
    'desc'     => 'Waterfall Model 400: 19 interactive water features, 2 waterslides and a single water battle zone. Requires a 2,000 sq ft minimum footprint and serves up to 100 water players. Application: shallow depth pool.',
    'images'   => array(),
    'specs'    => array(
      array( 'Venue Recommendation', 'Outdoor Water Parks; Indoor Water Parks; RV Campgrounds; Resorts; Recreational Facilities', null, null ),
      array( 'Unit Size (L/W/H)', '31’10” x 33’4″ x 23.5’', null, null ),
      array( 'Minimum Required Footprint', '2000', 'FTK', '2000 SQ. FT. / 185.8 SQ. M.' ),
      array( 'Waterslides', '2', 'C62', '2 – Enclosed tube slides' ),
      array( 'Top Deck Height', '108', 'INH', '108 IN. / 2.7 M.' ),
      array( 'Water Battle Zones', '1', 'C62', 'Single water battle zone' ),
      array( 'Interactive Water Feature Count', '19', 'C62', null ),
      array( 'User Capacity (structure + pool)', '100', 'C62', 'Up to 100 water players' ),
      array( 'Application', 'Shallow depth pool', null, null ),
    ),
    'faq'      => array(
      array( 'How much space does the Waterfall Model 400 need?',
             'The Waterfall Model 400 requires a minimum footprint of 2,000 sq ft / 185.8 sq m. The unit itself measures 31’10” x 33’4″ x 23.5’ (L/W/H), with a top deck height of 108 in / 2.7 m.' ),
      array( 'How many guests can the Waterfall Model 400 serve?',
             'Up to 100 water players. The structure carries 19 interactive water features and 2 – Enclosed tube slides.' ),
      array( 'What kind of pool does the Waterfall Model 400 install over?',
             'Shallow depth pool. All models can be customized with your selection of water play toys and designed to a footprint and scale that fits your facility.' ),
    ),
  ),

  // Water play features (15)
  '/products/water-play-features/water-play-features-beanstalk-blaster/' => array(
    'name'     => 'Beanstalk Blaster',
    'category' => 'Water Play Features',
    'desc'     => 'Get ready for an epic water battle with our high-flying blaster! Just push the button for an air-powered stream across the pool deck. This toy allows kids to aim and control the water’s direction by adjusting the handle’s height and pivoting side to side, creating a dynamic water flow. Perfect for pool floor installation, it sets the stage for non-stop fun and friendly competition! Typically, the Beanstalk Blaster is strategically positioned to create an action-packed battle zone between the pool floor and the structure-mounted blasters.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/beanstalk-blaster-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/beanstalk-gallery-01.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/beanstalk-gallery-03-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/beanstalk-gallery-04-1-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '29” x 29” x 96”', null, null ),
      array( 'Flow Requirements', '5', 'G2', '5 GPM' ),
      array( 'Components', 'Constructed from durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Stainless steel sensor that is IP69K; Assembly hardware is 316 stainless steel, features no sharp edges; This feature requires an air compressor provided by Interactive Play', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units; Lazy Rivers', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-cannon/' => array(
    'name'     => 'Cannon',
    'category' => 'Water Play Features',
    'desc'     => 'The Cannon is one of our premier and most exhilarating features that appeals to water players of every age. Even the adults love to get in on the water wars with this one! With the pull of a rope, a burst of air kicks into action, propelling water out in a thrilling, wide blast that will impress every guest.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/03/cannon-v3-01.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/03/cannon-v4-01.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/cannon-vertical-01-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '32” x 64” x 72”', null, null ),
      array( 'Flow Requirements', '10', 'G2', '10 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; Premium double-braided polyester pull rope; Assembly hardware is 316 stainless steel, features no sharp edges; The RGBW light bar is IP69K rated and has high brightness for daytime visibility; This feature requires an air compressor provided by Interactive Play', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units; Lazy Rivers', null, null ),
    ),
  ),

  '/products/water-play-features/fanatic/' => array(
    'name'     => 'Fanatic',
    'category' => 'Water Play Features',
    'desc'     => 'Experience endless fun with this engaging water feature that’s kid-activated with a pull rope. Once set in motion, the water dances out of the sweeping pipe and rushes through the fan nozzle. This nozzle boasts a wide spray pattern of approximately 120 degrees, creating a mesmerizing cascade that extends several feet creating a stimulating play experience for guests of all ages.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/03/fanatic-water-feature-01.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive', null, null ),
      array( 'Dimensions', '12” x 12” x 60”', null, null ),
      array( 'Flow Requirements', '5', 'G2', '5 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; The nozzle is cast bronze; Premium double-braided polyester pull rope; Assembly hardware is 316 stainless steel, features no exposed sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/jet-stream/' => array(
    'name'     => 'Jet Stream',
    'category' => 'Water Play Features',
    'desc'     => 'Children can revel in an exhilarating experience with the Jet Stream interactive water feature. This feature comes to life with a simple button press, unleashing a torrent of five powerful water jets that shoot straight down into the waiting pool. Plus, the water flow is entirely customizable for those seeking the perfect thrill level!',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/jet-stream-hero-01-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/03/jet-stream-water-feature-01.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/jet-stream-vertical-02-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/jet-stream-vertical-01-1-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive', null, null ),
      array( 'Dimensions', '15” x 48” x 92”', null, null ),
      array( 'Flow Requirements', '10', 'G2', '10 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; The push button is made from 304 stainless steel; Assembly hardware is 316 stainless steel, features no exposed sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-oh-chute/' => array(
    'name'     => 'Oh Chute',
    'category' => 'Water Play Features',
    'desc'     => 'Kids can dive into endless fun with the Oh Chute water wheel! As water flows from the fill spout, the water wheel springs to life, spinning and sending refreshing cascades below.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/gallery-oh-chute-03-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/OH-CHUTE-1-1-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/gallery-oh-chute-02-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/gallery-oh-chute-01-1.png',
    ),
    'specs'    => array(
      array( 'Dimensions', '58” x 40” x 72”', null, null ),
      array( 'Flow Requirements', '10', 'G2', '10 GPM' ),
      array( 'Components', '304 stainless steel fill spout; UHMW plastic bearing; Fiberglass water cups; Assembly hardware is 316 stainless steel, features no sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-pour-over/' => array(
    'name'     => 'Pour Over',
    'category' => 'Water Play Features',
    'desc'     => 'Get ready for a wet and wild adventure with this interactive! It’s all about making a splash and having a blast. The pull of the rope fills the clear cylinder on top, and then kids lift the lever to let the water flow – about 11 gallons of it! This interactive is perfect for waterslide endings and lazy riverbanks, where kids can soak their friends and engage in playful water games!',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/pour-over-hero-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/POUR-OVER-1-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/pour-over-gallery-02-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/pour-over-gallery-03-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive', null, null ),
      array( 'Dimensions', '96” x 16” x 133”', null, null ),
      array( 'Flow Requirements', '10', 'G2', '10 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; The water chamber is made from plexiglass; Assembly hardware is 316 stainless steel, features no sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units; Lazy Rivers', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-powerplunge/' => array(
    'name'     => 'Power Plunge',
    'category' => 'Water Play Features',
    'desc'     => 'This epic water wonder holds a staggering 750 gallons of aquatic excitement and reaches an impressive height of approximately 30 feet. The upper barrel steadily fills with water with each passing moment, building anticipation and setting the stage for an aquatic spectacle like no other.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/powerplunge-01-1-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '88” x 88” x 354”', null, null ),
      array( 'Water Volume', '750', 'GLL', 'Holds 750 gallons of water' ),
      array( 'Water Spray Pattern', '360-degree water spray', null, null ),
      array( 'Flow Requirements', '120', 'G2', '120 GPM' ),
      array( 'Components', 'Constructed from durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; This feature requires an air compressor provided by Interactive Play; The level sensor is IP69 rated and 316 stainless steel; The air cylinder is 304 stainless steel; The fill rate and dump timing can be adjusted by the throttle valve; The whistle can be adjusted with the PLC touchscreen', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/puddle-juggle/' => array(
    'name'     => 'Puddle Juggle',
    'category' => 'Water Play Features',
    'desc'     => 'Get ready for a world of tactile water play just for kids! Push the light-up touch sensor to activate this feature, and water flows from the top nozzle, making the teeter-totter sway left and right, creating playful effects that promote learning and motor skills.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/PUDDLE-JUGGLE-2-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive', null, null ),
      array( 'Dimensions', '54” x 34” x 8”', null, null ),
      array( 'Flow Requirements', '5', 'G2', '5 GPM' ),
      array( 'Components', '304 stainless steel fill spout; Assembly hardware is 316 stainless steel, features no sharp edges; Light-up touch sensor button', null, null ),
      array( 'Feature Applications', 'Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-rain-maker/' => array(
    'name'     => 'Rain Maker',
    'category' => 'Water Play Features',
    'desc'     => 'The Rain Maker interactive transforms into a hub of teamwork, fun, and new friendships. To bring the Rain Maker to life, kids collaborate by rocking the activation handle back and forth in a playful see-saw motion, which charges up this exciting attraction. As they rock the handle, it pumps up the air bellows beneath. A brilliant light bar provides a clear indication of the “charging status”. When the Rain Maker is fully charged, a powerful burst of air propels water into a magnificent vertical plume, shooting high into the sky!',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rain-maker-hero-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rainmaker-01-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rain-maker-vertical-01-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rain-maker-05.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '64” x 40” x 112”', null, null ),
      array( 'Flow Requirements', '10', 'G2', '10 GPM' ),
      array( 'Components', 'Constructed from durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; Assembly hardware is 316 stainless steel, features no sharp edges; The RGBW light bar is IP69K rated and has high brightness for daytime visibility; This feature requires an air compressor provided by Interactive Play', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-rusher/' => array(
    'name'     => 'Rusher',
    'category' => 'Water Play Features',
    'desc'     => 'Get ready for an absolute blast of fun with the Rusher interactive! This air-powered blaster is all about exciting adventures. Activate the Rusher with its built-in trigger on the handle. Kids adjust the aim of the blaster side to side and up and down, creating a dynamic water flow. Its low-friction design ensures its smooth and easy use, providing engagement and durability for users of all ages!',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rusher-hero-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rusher-water-feature-01-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rusher-gallery-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/rusher-gallery-05-1.jpg',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '32” x 14” x 44”', null, null ),
      array( 'Flow Requirements', '5', 'G2', '5 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; Assembly hardware is 316 stainless steel, features no sharp edges; Stainless steel sensor that is IP69K; This feature requires an air compressor provided by Interactive Play', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units; Lazy Rivers', null, null ),
    ),
  ),

  '/products/water-play-features/three-tree/' => array(
    'name'     => 'Three Tree',
    'category' => 'Water Play Features',
    'desc'     => 'The Three Tree interactive offers kids triple the fun with its three distinctive arms, each creating dynamic water effects. These arms, named Waterbender, Cloudburst, and Spout About, are sources of endless fun for the littlest adventurers. Activating the fun is a breeze; a simple spin of the wheel sets in motion an internal sensor that brings the corresponding arm to life.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/three-tree-hero-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/03/three-tree-water-feature-01.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive', null, null ),
      array( 'Dimensions', '56” x 52” x 97”', null, null ),
      array( 'Flow Requirements', '15', 'G2', '15 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Handwheels are 304 stainless steel with easy-turn for kids of all ages; Friction-free internal mechanism made from UHMW plastic; Assembly hardware is 316 stainless steel', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-thump-pump/' => array(
    'name'     => 'Thump Pump',
    'category' => 'Water Play Features',
    'desc'     => 'Get ready for interactive, friendly water wars! This feature is all about fun and excitement in our signature “water battle” zones. With a T-handle plunger, it’s incredibly easy for kids of any age to use. Just push down on the handle, and boom! A burst of air shoots up under the water through a drain grate installed on the pool floor, creating a thrilling splash just like a mine detonation. These interactives are perfect for enhancing a battle zone or can be a splashy adventure on their own!',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/thump-pump-01-1-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/THUMP-PUMP-1-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/thump-pump-02-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '13” x 10” x 29”', null, null ),
      array( 'Flow Requirements', '0', 'G2', '0 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; Stainless steel sensor that is IP69K; Assembly hardware is 316 stainless steel, features no sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units; Lazy Rivers', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-triple-buzz/' => array(
    'name'     => 'Triple Buzz',
    'category' => 'Water Play Features',
    'desc'     => 'All it takes is a simple hand wave, and voilà, the water nozzles spring to life. It’s like magic at the waterpark! This feature promotes immersive play by allowing kids to control the start and stop of water flow with an eight-inch-range digital proximity sensor. Each nozzle is equipped with an individual digital sensor mounted on the front of the interactive.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/tripple-buzz-hero-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/tripple-buzz-01-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Proximity Sensor Activated', null, null ),
      array( 'Dimensions', '26” x 12” x 35”', null, null ),
      array( 'Flow Requirements', '10', 'G2', '10 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; The nozzles are 303 stainless steel; Assembly hardware is 316 stainless steel, features no sharp edges; Plastic proximity sensor with a range of about 8 inches', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-wee-womper/' => array(
    'name'     => 'Wee Womper',
    'category' => 'Water Play Features',
    'desc'     => 'The Wee Womper transforms into the ultimate water blaster, igniting friendly water battles and fostering lively social play on the aquatic playground. Crafted especially with young adventurers in mind, it’s the perfect recipe for endless fun in the sun! Push the button tucked into the handle to set the aquatic adventure in motion! As kids give it a press – a friendly stream of water surges from the barrel that’s crafted for younger water players to enjoy.',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/wee-womper-hero-01-1.jpg',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/wee-womper-water-feature-01-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '14” x 32” x 36”', null, null ),
      array( 'Flow Requirements', '5', 'G2', '5 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Friction-free internal mechanism made from UHMW plastic; Assembly hardware is 316 stainless steel, features no sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units; Lazy Rivers', null, null ),
    ),
  ),

  '/products/water-play-features/water-play-features-white-wash/' => array(
    'name'     => 'WhiteWash',
    'category' => 'Water Play Features',
    'desc'     => 'Kids are in for an exhilarating and interactive experience with this thrilling feature. The excitement kicks off as they pull a rope, triggering a surge of water from a uniquely designed nozzle that functions like an inverted shower head. This creates a captivating play environment, simulating the joy of being caught in a delightful rain shower!',
    'images'   => array(
      'https://interactivewaterparks.com/wp-content/uploads/2024/03/whitewash-01.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/white-wash-vertical-01-1.png',
      'https://interactivewaterparks.com/wp-content/uploads/2024/04/white-wash-vertical2-01-1.png',
    ),
    'specs'    => array(
      array( 'Feature Details', 'Interactive; Air-Powered', null, null ),
      array( 'Dimensions', '12” x 12” x 63”', null, null ),
      array( 'Flow Requirements', '5', 'G2', '5 GPM' ),
      array( 'Components', 'Constructed of durable laser-cut 304 stainless steel; Corrosion and chemical-resistant coatings; Premium double-braided polyester rope; Friction-free internal mechanism made from UHMW plastic; Assembly hardware is 316 stainless steel, features no sharp edges', null, null ),
      array( 'Feature Applications', 'Splash Pads; Aquatic Play Units', null, null ),
    ),
  ),

);

function vpc_product_schema_graph( $path, $p ) {
	$base = 'https://interactivewaterparks.com';
	$url  = $base . $path;

	// Yoast already publishes the Organization node at $base . '/#organization'.
	// We reference it by @id rather than redefining it: two nodes sharing one @id
	// with different values is a conflict.

	$props = array();
	foreach ( $p['specs'] as $s ) {
		list( $label, $value, $unit, $desc ) = $s;
		$pv = array( '@type' => 'PropertyValue', 'name' => $label, 'value' => $value );
		if ( $unit ) $pv['unitCode']    = $unit;
		if ( $desc ) $pv['description'] = $desc;
		$props[] = $pv;
	}

	$product = array(
		'@type'       => 'Product',
		'@id'         => $url . '#product',
		'name'        => $p['name'],
		'category'    => $p['category'],
		'url'         => $url,
		'description' => $p['desc'],
		'brand'       => array( '@type' => 'Brand', 'name' => 'InterActive Play' ),
		'manufacturer'=> array( '@id' => $base . '/#organization' ),
		'additionalProperty' => $props,
	);
	if ( ! empty( $p['images'] ) ) $product['image'] = $p['images'];

	$graph = array( $product );

	if ( ! empty( $p['faq'] ) ) {
		$questions = array();
		foreach ( $p['faq'] as $f ) {
			$questions[] = array(
				'@type'          => 'Question',
				'name'           => $f[0],
				'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ),
			);
		}
		$graph[] = array(
			'@type'      => 'FAQPage',
			'@id'        => $url . '#faq',
			'url'        => $url,
			'mainEntity' => $questions,
		);
	}

	return array(
		'@context' => 'https://schema.org',
		'@graph'   => $graph,
	);
}

function vpc_emit_product_schema() {
	if ( is_admin() ) return;
	$path = trailingslashit( strtok( $_SERVER['REQUEST_URI'], '?' ) );
	if ( ! isset( $GLOBALS['VPC_PRODUCTS'][ $path ] ) ) return;

	$graph = vpc_product_schema_graph( $path, $GLOBALS['VPC_PRODUCTS'][ $path ] );
	echo "\n<script type=\"application/ld+json\">"
	   . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	   . "</script>\n";
}
add_action( 'wp_head', 'vpc_emit_product_schema', 20 );
