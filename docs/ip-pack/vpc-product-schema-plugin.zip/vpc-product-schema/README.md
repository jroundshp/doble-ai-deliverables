# InterActive Play — Product schema pack

Everything here publishes information **already written on the product pages**. It adds no
new claims about any product. The specifications exist; nothing marks them as specifications.

## Files

| File | What it is |
|---|---|
| `product-schema-template.json` | Fill-in-the-blanks template. Replace every `{{PLACEHOLDER}}`. |
| `triwave-100.json` | The template filled in for TriWave Model 100, as a worked example. |
| `vpc-product-schema.php` | Drop-in WordPress plugin (v1.1). One PHP array per product, no template edits. |

## The fastest route

1. Activate `vpc-product-schema.php`. The TriWave 100 entry is already filled in, and it is
   the only one, so activating changes exactly one URL on the site.
2. Open Google's Rich Results Test on `/products/aquatic-play-structures/triwave-100/`.
   Before: no product detected. After: a product with nine specifications.
3. Copy the TriWave block once per product, filling values from that page.
4. Nine aquatic play structures first. They carry the fullest spec sheets.

## Scope: 24 product pages, 5 categories, 1 hub

**Aquatic play structures (9)** — do these first, they have complete spec sheets:
`misty-island-100` · `misty-island-200` · `multi-level-water-play-unit-waterfall-model-400` ·
`triwave-100` · `triwave-200` · `triwave-300` · `waterfall-model-100` · `waterfall-model-200` ·
`waterfall-model-300`

**Water play features (15)** — smaller pages, same pattern:
`fanatic` · `jet-stream` · `puddle-juggle` · `three-tree` · `water-play-features-beanstalk-blaster` ·
`water-play-features-cannon` · `water-play-features-oh-chute` · `water-play-features-pour-over` ·
`water-play-features-powerplunge` · `water-play-features-rain-maker` · `water-play-features-rusher` ·
`water-play-features-thump-pump` · `water-play-features-triple-buzz` · `water-play-features-wee-womper` ·
`water-play-features-white-wash`

**Categories (6)** — `/products/` · `aquatic-play-structures` · `interactive-experiences` ·
`lazy-rivers` · `splash-pads` · `water-play-features`. These take `CollectionPage` with an
`ItemList` of the products beneath them, not `Product`.

## v1.1, 11 Sep 2026 — it no longer emits Organization or BreadcrumbList

Re-crawled the live site on 11 September. Yoast now publishes an `Organization` node at
`https://interactivewaterparks.com/#organization` (name, url, logo; **no address, no phone, no
parentOrganization**). It did not on 3 September, when this pack was written.

v1.0 defined its own `Organization` at **the same `@id`** with a different `name`. Two nodes
sharing one `@id` with conflicting values is a genuine conflict, not a duplicate. v1.1 drops the
node and references Yoast's by `@id` from `manufacturer` and `seller` instead. It also drops the
`BreadcrumbList`, which Yoast already emits correctly on every page.

**The pack now emits one thing: `Product`.** The address, phone and parent-company link belong in
Yoast's own Organization settings, which is a wp-admin screen rather than a file.

## Two deliberate decisions

**No price.** These are quoted capital purchases, not listed goods. A `Product` without a
`price` will not win a shopping-style rich result, and it should not try to. What it does win
is being parseable: a buyer or an assistant filtering on footprint, capacity or deck height
can find the unit. That is the entire objective. Do not add a fabricated price to satisfy a
validator warning.

**Unit codes.** `FTK` = square feet, `INH` = inches, `C62` = a plain count. These let a machine
compare 4,300 sq ft against a site constraint instead of reading it as a string.

## Before you ship, settle three contradictions on the TriWave page

Found while marking it up. Each is one number, and the marked-up version becomes the
authoritative one, so they are worth resolving first.

1. The meta description says **40 interactive features**. The spec sheet on the same page says
   **Interactive Water Feature Count: 20**.
2. The body copy says **four exciting slides**. The spec sheet says **2 closed flume tube slides**.
3. `Water Battle Zones` reads "Single water battle zone". Marked up as `1`. Confirm that is right.

The same pass is worth running on the other eight structures.
